@extends('theme-views.layouts.app')

@section('title', translate('Search Results for').' '.$query)

@section('content')
<div class="container py-4 rtl" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
    
    <!-- Header Section -->
    <div class="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-3 mb-4">
        <div>
            <h2 class="h4 mb-0 fw-bold">{{ translate('Search Results') }}</h2>
            <p class="text-muted mb-0 fs-14">
                {{ translate('Found') }} <strong class="text-primary">{{ $total }}</strong> {{ translate('items for') }} "<span class="fst-italic">{{ $query }}</span>"
            </p>
            @if(!empty($meta['did_you_mean']))
                <div class="mt-2 p-2 bg-light rounded text-center">
                    <span class="text-muted">{{ translate('Did you mean:') }}</span> 
                    <a href="{{ route('search', ['q' => $meta['did_you_mean']]) }}" class="fw-bold text-primary text-decoration-underline">
                        {{ $meta['did_you_mean'] }}?
                    </a>
                </div>
            @endif
        </div>
        
        <!-- Suggestions Tags -->
        @if(!empty($meta['suggestions']))
        <div class="d-none d-md-block">
            <small class="text-muted me-2">{{ translate('Related:') }}</small>
            @foreach($meta['suggestions'] as $suggestion)
                <a href="{{ route('search', ['q' => $suggestion]) }}" class="badge bg-light text-dark border fw-normal me-1 mb-1 hover-primary">
                    {{ $suggestion }}
                </a>
            @endforeach
        </div>
        @endif
    </div>

    <div class="row g-4">
        <!-- Sidebar Filters -->
        <div class="col-lg-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="fw-bold border-bottom pb-2 mb-3">{{ translate('Filter By') }}</h5>
                    
                    @if(!empty($facets['brands']))
                    <div class="mb-4">
                        <label class="fw-semibold mb-2">{{ translate('Brands') }}</label>
                        <ul class="list-unstyled">
                            @foreach($facets['brands'] as $brandName => $count)
                                <li class="d-flex justify-content-between align-items-center mb-2">
                                    <a href="{{ route('search', array_merge(request()->all(), ['brand' => $brandName])) }}" class="text-dark text-decoration-none {{ request('brand') == $brandName ? 'fw-bold text-primary' : '' }}">
                                        {{ $brandName }}
                                    </a>
                                    <span class="badge bg-light text-muted rounded-pill">{{ $count }}</span>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    @endif

                    @if(!empty($facets['price_ranges']))
                    <div class="mb-4">
                        <label class="fw-semibold mb-2">{{ translate('Price Range') }}</label>
                        <ul class="list-unstyled">
                            <li class="mb-2"><a href="{{ route('search', array_merge(request()->all(), ['price_max' => 25])) }}" class="text-muted text-decoration-none">{{ translate('Under') }} $25</a></li>
                            <li class="mb-2"><a href="{{ route('search', array_merge(request()->all(), ['price_min' => 25, 'price_max' => 50])) }}" class="text-muted text-decoration-none">$25 - $50</a></li>
                            <li class="mb-2"><a href="{{ route('search', array_merge(request()->all(), ['price_min' => 50, 'price_max' => 100])) }}" class="text-muted text-decoration-none">$50 - $100</a></li>
                            <li class="mb-2"><a href="{{ route('search', array_merge(request()->all(), ['price_min' => 100])) }}" class="text-muted text-decoration-none">{{ translate('Over') }} $100</a></li>
                        </ul>
                    </div>
                    @endif
                    
                    @if(request()->hasAny(['brand', 'price_min', 'price_max', 'category']))
                        <a href="{{ route('search', ['q' => $query]) }}" class="btn btn-outline-danger w-100 btn-sm">
                            <i class="bi bi-x-circle"></i> {{ translate('Clear Filters') }}
                        </a>
                    @endif
                </div>
            </div>
        </div>

        <!-- Product Grid -->
        <div class="col-lg-9">
            @if($products->count() > 0)
                <div class="row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 g-3">
                    @foreach($products as $product)
                        <div class="col">
                            <div class="product-card card h-100 border-0 shadow-sm hover-shadow transition-all">
                                <!-- Image -->
                                <div class="card-header border-0 bg-transparent p-0 position-relative">
                                    <a href="{{route('product',$product->slug)}}" class="d-block h-100">
                                        <img src="{{ getStorageImages(path: $product->thumbnail_full_url, type: 'product') }}" 
                                             onerror="this.src='{{ theme_asset('assets/img/image-place-holder.png') }}'"
                                             class="card-img-top img-fluid" 
                                             style="height: 200px; object-fit: cover;"
                                             alt="{{ $product->name }}">
                                    </a>
                                    @if($product->discount > 0)
                                        <span class="position-absolute top-0 start-0 m-2 badge bg-danger rounded-pill">
                                            -{{ $product->discount_type == 'percent' ? $product->discount.'%' : \App\Utils\Helpers::currency_converter($product->discount) }}
                                        </span>
                                    @endif
                                </div>

                                <!-- Body -->
                                <div class="card-body p-3 d-flex flex-column">
                                    <div class="mb-1 text-muted fs-12">{{ $product->category->name ?? translate('Uncategorized') }}</div>
                                    <h6 class="card-title text-truncate fw-bold mb-2">
                                        <a href="{{route('product',$product->slug)}}" class="text-dark text-decoration-none" title="{{ $product->name }}">
                                            {{ Str::limit($product->name, 40) }}
                                        </a>
                                    </h6>

                                    <!-- Price -->
                                    <div class="mt-auto">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="fw-bold text-primary fs-16">
                                                {{ \App\Utils\Helpers::currency_converter($product->unit_price - \App\Utils\Helpers::get_product_discount($product, $product->unit_price)) }}
                                            </span>
                                            @if($product->discount > 0)
                                                <span class="text-muted text-decoration-line-through fs-12">
                                                    {{ \App\Utils\Helpers::currency_converter($product->unit_price) }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Pagination (Optional - simple links) -->
                <div class="mt-4 d-flex justify-content-center">
                    @if($total > 20)
                        <div class="alert alert-info py-2 px-3">
                            {{ translate('Showing top 20 results. Refine your search to see more.') }}
                        </div>
                    @endif
                </div>

            @else
                <!-- No Results -->
                <div class="text-center py-5">
                    <img src="{{ theme_asset('assets/img/empty-cart.png') }}" class="mb-3" style="width: 150px; opacity: 0.5;">
                    <h3 class="h5 fw-bold text-muted">{{ translate('No products found') }}</h3>
                    <p class="text-muted">{{ translate('Try checking your spelling or use different keywords.') }}</p>
                    <a href="{{ route('home') }}" class="btn btn-primary">{{ translate('Back to Home') }}</a>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection