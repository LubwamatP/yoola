<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\Product;

class AdvancedSearchService
{
    private array $config;
    private array $synonyms;
    private array $stopWords;
    
    public function __construct()
    {
        $this->config = [
            'max_results' => 100, // Increased slightly for better filtering
            'cache_ttl' => 3600,
        ];
        
        $this->synonyms = [
            'phone' => ['smartphone', 'mobile', 'iphone', 'android'],
            'laptop' => ['notebook', 'pc', 'macbook', 'computer'],
            'tv' => ['television', 'smart tv', 'led', 'oled', 'qled'],
            'cooker' => ['oven', 'stove', 'gas cooker', 'cookers', 'microwave'],
            'fridge' => ['refrigerator', 'freezer', 'icebox'],
            'aircon' => ['ac', 'air conditioner', 'cooling'],
        ];
        
        $this->stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'buy', 'sale'];
    }
    
    public function search(string $query, array $filters = [], int $perPage = 20): array
    {
        // V8 Cache Key: Includes filters to ensure sidebar clicks update the results
        $cacheKey = 'search_v8_pro:' . md5($query . json_encode($filters));
        
        return Cache::remember($cacheKey, $this->config['cache_ttl'], function () use ($query, $filters, $perPage) {
            
            // 1. PARSE
            $parsedQuery = $this->parseQuery($query);
            $expandedTerms = $this->expandQuery($parsedQuery['clean_tokens']);
            
            // 2. EXECUTE (Now respects Filters)
            $results = $this->executeSearch($parsedQuery, $expandedTerms, $filters);
            
            // 3. GENERATE FACETS (Before pagination/slicing to get accurate global counts)
            $facets = $this->generateFacets($results);
            
            // 4. SCORE & SORT
            $scoredResults = $this->scoreResults($results, $expandedTerms);
            $sortedResults = $scoredResults->sortByDesc('relevance_score')->values();
            
            // 5. PAGINATE
            $currentPage = LengthAwarePaginator::resolveCurrentPage();
            $currentItems = $sortedResults->slice(($currentPage - 1) * $perPage, $perPage)->all();
            
            $paginator = new LengthAwarePaginator($currentItems, $sortedResults->count(), $perPage, $currentPage, [
                'path' => LengthAwarePaginator::resolveCurrentPath(),
            ]);

            return [
                'results' => $paginator,
                'total' => $sortedResults->count(),
                'intent' => [],
                'filters_applied' => $filters,
                'suggestions' => [],
                'did_you_mean' => null,
                'facets' => $facets, // Now populated!
            ];
        });
    }

    private function executeSearch(array $parsedQuery, array $expandedTerms, array $filters): Collection
    {
        if (!class_exists(Product::class)) {
            return collect([]);
        }
        
        // Phase 1: Strict Search (All Terms Match)
        $strictQuery = $this->getBaseQuery($filters);
        $originalTokens = $parsedQuery['clean_tokens'];
        $results = new Collection();

        if (count($originalTokens) > 0) {
             $strictQuery->where(function ($q) use ($originalTokens) {
                foreach ($originalTokens as $token) {
                    $q->where('name', 'LIKE', "%{$token}%");
                }
             });
             $results = $strictQuery->limit(40)->get();
        }

        // Phase 2: Broad Search (Any Term Matches) - Only if we need more results
        if ($results->count() < $this->config['max_results']) {
            $idsToExclude = $results->pluck('id')->toArray();
            $remainingLimit = $this->config['max_results'] - $results->count();
            
            $broadQuery = $this->getBaseQuery($filters); // Apply filters here too!
            
            if (!empty($idsToExclude)) {
                $broadQuery->whereNotIn('id', $idsToExclude);
            }

            if (!empty($expandedTerms)) {
                $broadQuery->where(function ($q) use ($expandedTerms) {
                    foreach ($expandedTerms as $term) {
                        $q->orWhere('name', 'LIKE', "%{$term}%");
                    }
                });
            }
            
            $broadResults = $broadQuery->limit($remainingLimit)->get();
            $results = $results->merge($broadResults);
        }

        return $results;
    }
    
    /**
     * Creates the base query and applies active filters (Brand, Price, Category)
     */
    private function getBaseQuery(array $filters = [])
    {
        $query = Product::query();
        
        // Select specific columns for performance
        $query->select([
            'id', 
            'name', 
            'slug', 
            'thumbnail', 
            'unit_price', 
            'purchase_price', 
            'discount', 
            'discount_type', 
            'tax', 
            'tax_type', 
            'brand_id', 
            'category_ids'
        ]);

        // Eager load relations for display and scoring
        try {
            $query->with(['brand', 'category']); // Assuming 'category' relation exists
        } catch (\Throwable $e) {}
        
        // --- APPLY FILTERS ---
        
        // 1. Brand Filter (Name or ID)
        if (!empty($filters['brand'])) {
            $query->whereHas('brand', function($q) use ($filters) {
                $q->where('name', $filters['brand']);
            });
        }

        // 2. Price Range
        if (!empty($filters['price_min'])) {
            $query->where('unit_price', '>=', $filters['price_min']);
        }
        if (!empty($filters['price_max'])) {
            $query->where('unit_price', '<=', $filters['price_max']);
        }
        
        // 3. Category (if provided in filters)
        if (!empty($filters['category'])) {
             $query->whereHas('category', function($q) use ($filters) {
                $q->where('name', $filters['category']);
            });
        }

        $query->where('status', 1);
        return $query;
    }

    /**
     * Generates sidebar counts based on the actual results found
     */
    private function generateFacets(Collection $results): array
    {
        $facets = [
            'brands' => [],
            'price_ranges' => [],
            'categories' => []
        ];

        if ($results->isEmpty()) return $facets;

        // 1. Count Brands
        // Group by Brand Name and count occurrences
        $facets['brands'] = $results->whereNotNull('brand')
            ->groupBy(fn($item) => $item->brand->name ?? 'Unknown')
            ->map->count()
            ->sortDesc() // Most popular first
            ->toArray();

        // 2. Determine Categories (Optional, useful for "Did you mean X category?")
        $facets['categories'] = $results->whereNotNull('category')
            ->groupBy(fn($item) => $item->category->name ?? 'Unknown')
            ->map->count()
            ->sortDesc()
            ->take(5)
            ->toArray();

        return $facets;
    }

    // --- SCORING & PARSING HELPERS (Kept from previous stable version) ---

    private function parseQuery(string $query): array
    {
        $original = trim($query);
        $lowercase = mb_strtolower($original);
        $tokens = preg_split('/[\s\-\_\+]+/', $lowercase, -1, PREG_SPLIT_NO_EMPTY);
        $cleanTokens = array_filter($tokens, fn($token) => !in_array($token, $this->stopWords));
        
        return [
            'clean_tokens' => array_values($cleanTokens),
        ];
    }

    private function expandQuery(array $tokens): array
    {
        $expanded = $tokens;
        foreach ($tokens as $token) {
            if (isset($this->synonyms[$token])) {
                $expanded = array_merge($expanded, $this->synonyms[$token]);
            }
            if (strlen($token) > 3 && str_ends_with($token, 's')) {
                $expanded[] = substr($token, 0, -1);
            }
            $expanded[] = $token . 's';
        }
        return array_unique($expanded);
    }

    private function scoreResults(Collection $results, array $searchTerms): Collection
    {
        return $results->map(function ($product) use ($searchTerms) {
            $score = 0;
            
            $nameLower = mb_strtolower((string)($product->name ?? ''));
            // Access relation names safely
            $categoryLower = mb_strtolower((string)($product->category->name ?? ''));
            $brandLower = mb_strtolower((string)($product->brand->name ?? ''));
            
            $termsFound = 0;

            foreach ($searchTerms as $term) {
                $termMatched = false;

                // Prioritize Category Matches (Cookers > TVs)
                if (!empty($categoryLower) && str_contains($categoryLower, $term)) {
                    $score += 500; 
                    $termMatched = true;
                }
                
                // Prioritize Brand Matches
                if (!empty($brandLower) && str_contains($brandLower, $term)) {
                    $score += 100;
                    $termMatched = true;
                }

                // Standard Name Match
                if (str_contains($nameLower, $term)) {
                    $score += 50;
                    $termMatched = true;
                }
                
                if ($termMatched) $termsFound++;
            }
            
            // Boost products that match multiple keywords
            if ($termsFound > 1) {
                $score += ($termsFound * 150);
            }

            $product->relevance_score = $score;
            return $product;
        });
    }
}