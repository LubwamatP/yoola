<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\Product;

class AdvancedSearchService
{
    private array $config;
    private array $synonyms;
    private array $stopWords;
    
    public function __construct()
    {
        $this->config = [
            'max_results' => 60, // Keeps memory usage safe
            'cache_ttl' => 3600,
        ];
        
        // Synonyms allow "oven" to find "cooker"
        $this->synonyms = [
            'phone' => ['smartphone', 'mobile'],
            'laptop' => ['notebook', 'pc'],
            'tv' => ['television', 'smart tv'],
            'cooker' => ['oven', 'stove', 'gas cooker', 'cookers'], // Added cookers explicitly
            'fridge' => ['refrigerator', 'freezer'],
        ];
        $this->stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with'];
    }
    
    public function search(string $query, array $filters = [], int $perPage = 20): array
    {
        // NEW CACHE KEY: search_v7_strict (Forces the system to ignore old broken cache)
        $cacheKey = 'search_v7_strict:' . md5($query . json_encode($filters));
        
        return Cache::remember($cacheKey, $this->config['cache_ttl'], function () use ($query, $filters, $perPage) {
            
            // 1. CLEAN & EXPAND QUERY
            $parsedQuery = $this->parseQuery($query);
            $expandedTerms = $this->expandQuery($parsedQuery['clean_tokens']);
            
            // 2. EXECUTE SMART SEARCH (Strict First, Then Broad)
            $results = $this->executeSearch($parsedQuery, $expandedTerms, $filters);
            
            // 3. SCORE RESULTS (Boost Category Matches)
            $scoredResults = $this->scoreResults($results, $expandedTerms);
            
            // Sort by relevance score (High -> Low)
            $sortedResults = $scoredResults->sortByDesc('relevance_score')->values();
            
            // 4. PAGINATE
            $currentPage = LengthAwarePaginator::resolveCurrentPage();
            $currentItems = $sortedResults->slice(($currentPage - 1) * $perPage, $perPage)->all();
            $paginator = new LengthAwarePaginator($currentItems, $sortedResults->count(), $perPage, $currentPage, [
                'path' => LengthAwarePaginator::resolveCurrentPath(),
            ]);

            return [
                'results' => $paginator,
                'total' => $sortedResults->count(),
                'intent' => [],
                'filters_applied' => $filters,
                'suggestions' => [],
                'did_you_mean' => null,
                'facets' => [],
            ];
        });
    }

    private function executeSearch(array $parsedQuery, array $expandedTerms, array $filters): Collection
    {
        if (!class_exists(Product::class)) {
            throw new \Exception("Product Model not found.");
        }
        
        // --- PHASE 1: STRICT SEARCH ---
        // Find products that contain ALL original words (e.g. "Cooker" AND "Hisense")
        // This ensures exact matches appear even if TVs flood the database.
        
        $strictQuery = $this->getBaseQuery();
        $originalTokens = $parsedQuery['clean_tokens'];
        $results = new Collection();

        // Only run strict search if we have multiple words
        if (count($originalTokens) > 0) {
             $strictQuery->where(function ($q) use ($originalTokens) {
                foreach ($originalTokens as $token) {
                    $q->where('name', 'LIKE', "%{$token}%");
                }
             });
             // Get top 30 strict matches
             $results = $strictQuery->limit(30)->get();
        }

        // --- PHASE 2: BROAD SEARCH ---
        // If strict search didn't fill the limit (60), fill the rest with "Any Match"
        // This handles "Cookers" (finding "Cooker") or single keywords.
        
        if ($results->count() < $this->config['max_results']) {
            $idsToExclude = $results->pluck('id')->toArray();
            $remainingLimit = $this->config['max_results'] - $results->count();
            
            $broadQuery = $this->getBaseQuery();
            
            if (!empty($idsToExclude)) {
                $broadQuery->whereNotIn('id', $idsToExclude);
            }

            if (!empty($expandedTerms)) {
                $broadQuery->where(function ($q) use ($expandedTerms) {
                    foreach ($expandedTerms as $term) {
                        $q->orWhere('name', 'LIKE', "%{$term}%");
                    }
                });
            }
            
            $broadResults = $broadQuery->limit($remainingLimit)->get();
            $results = $results->merge($broadResults);
        }

        return $results;
    }
    
    // Helper to create a fresh query with relations
    private function getBaseQuery()
    {
        $query = Product::query();
        try {
            $query->with(['category', 'brand']);
        } catch (\Throwable $e) {}
        
        $query->where('status', 1);
        return $query;
    }

    private function parseQuery(string $query): array
    {
        $original = trim($query);
        $lowercase = mb_strtolower($original);
        $tokens = preg_split('/[\s\-\_\+]+/', $lowercase, -1, PREG_SPLIT_NO_EMPTY);
        $cleanTokens = array_filter($tokens, fn($token) => !in_array($token, $this->stopWords));
        
        return [
            'clean_tokens' => array_values($cleanTokens),
        ];
    }

    private function expandQuery(array $tokens): array
    {
        $expanded = $tokens;
        foreach ($tokens as $token) {
            // 1. Add Synonyms
            if (isset($this->synonyms[$token])) {
                $expanded = array_merge($expanded, $this->synonyms[$token]);
            }
            
            // 2. Handle Plurals (Simple Logic)
            // "Cookers" -> "Cooker"
            if (strlen($token) > 3 && str_ends_with($token, 's')) {
                $singular = substr($token, 0, -1);
                $expanded[] = $singular;
            }
            
            // "Cooker" -> "Cookers"
            $expanded[] = $token . 's';
        }
        return array_unique($expanded);
    }

    private function scoreResults(Collection $results, array $searchTerms): Collection
    {
        return $results->map(function ($product) use ($searchTerms) {
            $score = 0;
            
            // Safely get text fields (Casting to string fixes null errors)
            $nameLower = mb_strtolower((string)($product->name ?? ''));
            $categoryLower = mb_strtolower((string)($product->category->name ?? ''));
            $brandLower = mb_strtolower((string)($product->brand->name ?? ''));
            
            $termsFound = 0;

            foreach ($searchTerms as $term) {
                $termMatched = false;

                // RULE 1: Category Match gets HUGE points (500)
                // This ensures "Cooker" puts items in the Cooker Category above TVs.
                if (!empty($categoryLower) && str_contains($categoryLower, $term)) {
                    $score += 500; 
                    $termMatched = true;
                }
                
                // RULE 2: Brand Match gets HIGH points (100)
                if (!empty($brandLower) && str_contains($brandLower, $term)) {
                    $score += 100;
                    $termMatched = true;
                }

                // RULE 3: Name Match gets STANDARD points (50)
                if (str_contains($nameLower, $term)) {
                    $score += 50;
                    $termMatched = true;
                }
                
                if ($termMatched) {
                    $termsFound++;
                }
            }
            
            // RULE 4: "AND" Logic Bonus
            // If a product matches multiple terms, boost it.
            if ($termsFound > 1) {
                $score += ($termsFound * 100);
            }

            $product->relevance_score = $score;
            return $product;
        });
    }
}